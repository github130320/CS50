#include<stdio.h>

/**
* main: The program prints the average of 3 scores.
* 
* Return: no return.
*/

int main(void)

{
    int score1 = 72;
    int score2 = 73;
    int score3 = 33;
    {
        printf("Average: %f\n", (score1 + score2 + score3) / 3.0);
    }
}
